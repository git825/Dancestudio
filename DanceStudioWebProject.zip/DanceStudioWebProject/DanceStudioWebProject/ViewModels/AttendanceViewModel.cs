﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DanceStudioWebProject.Models;
using System.ComponentModel.DataAnnotations;

namespace DanceStudioWebProject.ViewModels
{
    public class AttendanceViewModel
    {
        [Key]
        public int BookingId { get; set; }
        public string isPresent { get; set; }
        [Display(Name = "Student")]
        public string CustomerName { get; set; }
    }
}
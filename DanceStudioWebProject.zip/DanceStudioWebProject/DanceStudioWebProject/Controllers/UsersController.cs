﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using DanceStudioWebProject.Models;
using DanceStudioWebProject.ViewModels;

namespace DanceStudioWebProject.Controllers
{
    public class UsersController : Controller
    {
        private Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();

        // GET: Users
        public ActionResult Index()
        {
            return View();
        }

        // GET: Users/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // GET: Users/Create
        public ActionResult Register()
        {
            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Register([Bind(Include = "username,Name,password,DanceType,Email,Gender,DOB,City,MobileNumber")] User user)
        {
            if (ModelState.IsValid)
            {
                string msg = "Invalid Date of Birth,enter the DOB B/W 1980-2012";
                DateTime dob = Convert.ToDateTime(user.DOB);
                var startdate = DateTime.ParseExact("01/01/1980","dd/MM/yyyy", null);
                var enddate = DateTime.ParseExact("31/12/2012","dd/MM/yyyy", null);
                if (dob.Date > startdate.Date && dob.Date <= enddate.Date)
                {
                    db.Users.Add(user);
                    UserLoginCredential newuser = new UserLoginCredential() { username = user.username, password = user.password };
                    db.UserLoginCredentials.Add(newuser);
                    db.SaveChanges();
                    return Content("<html><head><script>alert('Successfully Registered'); window.location.href = '/Users/Login'</script></head></html>");
                    // return RedirectToAction("Login");
                }
                ModelState.AddModelError("dob", msg);
            }
            return View(user);
        }


        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(UserLoginCredential user)
        {
            if (user.username != null)
            {
                var res = db.UserLoginCredentials.Where(a => a.username == user.username).SingleOrDefault();
                if (res != null)
                {
                    if (res.password == user.password)
                    {
                        Session["isLogin"] = "true";
                        Session["username"] = res.username;
                        Session["UserId"] = res.username;
                        Session["Usertype"] = "user";
                        return RedirectToAction("Index", "Users");
                    }
                    else
                    {
                        ModelState.AddModelError("password", "password not match");
                    }
                }
                else
                {
                    ModelState.AddModelError("username", "username not exist");
                }
            }
            return View();
        }

        public ActionResult Logout()
        {
            Session.RemoveAll();
            Session.Abandon();
            Session.Clear();
            return Content("<html><head><script> window.history.forward(1); window.location.href = '/Users/Login'</script></head></html>");
        }

        // GET: Users/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // POST: Users/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "username,password,DanceType,Email,Gender,DOB,City,MobileNumber")] User user)
        {
            if (ModelState.IsValid)
            {
                db.Entry(user).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(user);
        }

        // GET: Users/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            User user = db.Users.Find(id);
            db.Users.Remove(user);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult danceTypes()
        {
            return View();
        }

        [HttpPost]
        public ActionResult danceTypes(string dancetype)
        {
            Session["danceType"] = dancetype;
            return RedirectToAction("showChoreographers", "Users");
        }

        public ActionResult showChoreographers()
        {
            string danceType = Session["danceType"].ToString();
            var res = db.choreographers.Where(a => a.DanceType == danceType).ToList();
            return View(res);
        }

        public ActionResult bookChoreographer(string selectedChoreographer, string danceType)
        {
            Session["selectedChoreographer"] = selectedChoreographer;
            Session["danceType"] = danceType;
            return View();
        }

        [HttpPost]
        public ActionResult bookChoreographer(BookChoreographer bookChoreographer)
        {
            if (ModelState.IsValid)
            {
                string msg = "booking date b/w current date year to last date year(2020) ";
                DateTime bd = Convert.ToDateTime(bookChoreographer.BookingDate);
                var startdate = DateTime.Now;
                var enddate = DateTime.ParseExact("31/12/2020", "dd/MM/yyyy", null);
                if (bd.Date > startdate.Date && bd.Date <= enddate.Date)
                {
                    //var bookeddate = bookChoreographer.BookingDate.ToString("d");
                    string chname = Session["selectedChoreographer"].ToString();
                    var res = db.BookChoreographers.Where(a => a.choreographername == chname && a.BookingStatus == "Pending" && (a.BookingDate.Year == bookChoreographer.BookingDate.Year && a.BookingDate.Month == bookChoreographer.BookingDate.Month && a.BookingDate.Day == bookChoreographer.BookingDate.Day)).ToList();
                    if (res.Count == 0)
                    {
                        if (saveBookingDetails(bookChoreographer))
                        {
                            return Content("<html><head><script>alert('Successfully Booked'); window.location.href = '/Users/Index'</script></head></html>");
                            //return RedirectToAction("Index", "Users");
                        }
                    }
                    else
                    {
                        if (res.Count < 3)
                        {
                            if (res[0].City == bookChoreographer.City && (res[0].BookingDate.Year == bookChoreographer.BookingDate.Year && res[0].BookingDate.Month == bookChoreographer.BookingDate.Month && res[0].BookingDate.Day == bookChoreographer.BookingDate.Day))
                            {
                                if (saveBookingDetails(bookChoreographer))
                                {
                                    return Content("<html><head><script>alert('Successfully Booked'); window.location.href = '/Users/Index'</script></head></html>");
                                    //return RedirectToAction("Index", "Users");
                                }
                            }
                            else if (res[0].City != bookChoreographer.City && (res[0].BookingDate.Year != bookChoreographer.BookingDate.Year && res[0].BookingDate.Month != bookChoreographer.BookingDate.Month && res[0].BookingDate.Day != bookChoreographer.BookingDate.Day))
                            {
                                if (saveBookingDetails(bookChoreographer))
                                {
                                    return Content("<html><head><script>alert('Successfully Booked'); window.location.href = '/Users/Index'</script></head></html>");
                                    //return RedirectToAction("Index", "Users");
                                }
                            }
                            ModelState.AddModelError("choreographername", "Selected Choreographer has Booking on Same Date in different Location");
                        }
                        else
                        {
                            ModelState.AddModelError("choreographername", "the selected Choreographer has limited bookings ,Only 3 Booking can be done per a day");
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("BookingDate", msg);
                }
            }
            return View();
        }

        public bool saveBookingDetails(BookChoreographer bookChoreographer)
        {
            bool isSaved = false;
            try
            {
                bookChoreographer.StudentName = Session["username"].ToString();
                bookChoreographer.choreographername = Session["selectedChoreographer"].ToString();
                bookChoreographer.BookingStatus = "Pending";
                bookChoreographer.Attendancegiven = "No";
                bookChoreographer.Rewardsgiven = "No";
                db.BookChoreographers.Add(bookChoreographer);
                db.SaveChanges();
                sendEmail(bookChoreographer.Email, "Choreographer booked Successfully", $"Choreographer {bookChoreographer.choreographername} booking pending for approval");
                isSaved = true;
                return isSaved;
            }
            catch (Exception)
            {
                return isSaved;
            }
        }

        public ActionResult bookingStatus()
        {
            string user = Session["username"].ToString();
            var res = db.BookChoreographers.Where(a => a.StudentName == user).ToList();
            return View(res);
        }

        public ActionResult viewRewards()
        {
            string name = Session["username"].ToString();
            var res = db.Rewards.Where(a => a.StudentName == name).ToList();
            return View(res);
        }

        public void sendEmail(string receiver, string subject, string message)
        {

                string email1 = "prabhakar.gunde@capgemini.com";
                //string email1 = "prabhakar.heart007@gmail.com";
                string password = "pavikanna@1722";

                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.outlook.com");
                //SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress(email1, "Admin");
                mail.To.Add(receiver);
                mail.Subject = subject;

                string body = message;
                mail.Body = body;
                mail.IsBodyHtml = true;
                //SmtpServer.UseDefaultCredentials = false;
                SmtpServer.Port = 25;
                SmtpServer.Credentials = new System.Net.NetworkCredential(email1, password);
                SmtpServer.EnableSsl = true;
                SmtpServer.Send(mail);
        }

        public ActionResult Feedback()
        {
            string user = Session["username"].ToString();
            var bookings = db.BookChoreographers.Where(a => a.StudentName == user && a.BookingStatus == "Accepted" && a.Attendancegiven == "Yes").ToList();
            var feedbacks = db.Feedbacks.ToList();
            List<int> feedbackBookingsId = new List<int>();
            foreach (var item in feedbacks)
            {
                feedbackBookingsId.Add(Convert.ToInt32(item.BookingId));
            }
            List<Feedback> feedbacklist = new List<Feedback>();
            foreach (var item in bookings)
            {
                if (!feedbackBookingsId.Contains(item.BookingId))
                {
                    Feedback feedback = new Feedback()
                    {
                        BookingId = item.BookingId,
                        StudentName = item.StudentName,
                        ChoreographerName = item.choreographername
                    };
                    feedbacklist.Add(feedback);
                }
            }
            return View(feedbacklist);
        }

        [HttpPost]
        public ActionResult Feedback(List<Feedback> feedbackList)
        {
            string user = Session["username"].ToString();
            foreach (var item in feedbackList)
            {
                Feedback newFeedBack = new Feedback() { BookingId = item.BookingId, StudentName = item.StudentName, ChoreographerName = item.ChoreographerName, Feedback1 = item.Feedback1 };
                db.Feedbacks.Add(newFeedBack);
            }
            db.SaveChanges();
            return Json("Success", JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult IsAlreadyExists(string username)
        {
            return Json(IsUsernameAvailable(username));
        }

        public bool IsUsernameAvailable(string username)
        {
            bool status = true;
            var UsernameExists = db.Users.Where(a => a.username.ToUpper() == username.ToUpper()).FirstOrDefault();
            if (UsernameExists != null)
            {
                status = false;
                return status;
            }
            return status;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

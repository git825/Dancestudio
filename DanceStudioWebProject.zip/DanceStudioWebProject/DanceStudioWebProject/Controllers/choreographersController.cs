﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DanceStudioWebProject.Models;
using DanceStudioWebProject.ViewModels;

namespace DanceStudioWebProject.Controllers
{
    public class choreographersController : Controller
    {
        private Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();

        // GET: choreographers
        public ActionResult Index()
        {
            return View();
        }

        // GET: choreographers/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            choreographer choreographer = db.choreographers.Find(id);
            if (choreographer == null)
            {
                return HttpNotFound();
            }
            return View(choreographer);
        }

        // GET: choreographers/Create
        public ActionResult Register()
        {
            return View();
        }

        // POST: choreographers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Register([Bind(Include = "username,Name,password,DanceType,Email,Gender,DOB,City,MobileNumber")] choreographer choreographer)
        {
            //string msg = "Something Went Wrong";
            if (ModelState.IsValid)
            {
                string msg = "Invalid Date of Birth,enter the DOB B/W 1970-2003";
                DateTime dob = Convert.ToDateTime(choreographer.DOB);
                var startdate = DateTime.ParseExact("01/01/1970", "dd/MM/yyyy", null);
                var enddate = DateTime.ParseExact("31/12/2003", "dd/MM/yyyy", null);
                if (dob.Date > startdate.Date && dob.Date <= enddate.Date)
                {
                    db.choreographers.Add(choreographer);
                    ChoreographerLoginCredential newchoreographer = new ChoreographerLoginCredential() { username = choreographer.username, password = choreographer.password };
                    db.ChoreographerLoginCredentials.Add(newchoreographer);
                    db.SaveChanges();
                    return Content("<html><head><script>alert('Successfully Registered'); window.location.href = '/choreographers/Login'</script></head></html>");
                }
                ModelState.AddModelError("dob", msg);
                //msg = "successfully created";
            }
            //return new JsonResult { Data = new { message = msg } };
            return View(choreographer);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(ChoreographerLoginCredential choreographer)
        {
            if (choreographer.username != null)
            {
                var res = db.ChoreographerLoginCredentials.Where(a => a.username == choreographer.username).SingleOrDefault();
                if (res != null)
                {
                    if (res.password == choreographer.password)
                    {
                        Session["isLogin"] = "true";
                        Session["username"] = res.username;
                        Session["UserId"] = res.username;
                        Session["Usertype"] = "choreographer";
                        return RedirectToAction("Index", "choreographers");
                    }
                    else
                    {
                        ModelState.AddModelError("password", "password not match");
                    }
                }
                else
                {
                    ModelState.AddModelError("username", "username not exist");
                }
            }
            return View();
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login", "choreographers");
            //return RedirectToAction("Index", "Home");
        }


        // GET: choreographers/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            choreographer choreographer = db.choreographers.Find(id);
            if (choreographer == null)
            {
                return HttpNotFound();
            }
            return View(choreographer);
        }

        // POST: choreographers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "username,Name,password,DanceType,Email,Gender,DOB,City,MobileNumber")] choreographer choreographer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(choreographer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(choreographer);
        }

        // GET: choreographers/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            choreographer choreographer = db.choreographers.Find(id);
            if (choreographer == null)
            {
                return HttpNotFound();
            }
            return View(choreographer);
        }

        // POST: choreographers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            choreographer choreographer = db.choreographers.Find(id);
            db.choreographers.Remove(choreographer);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult ViewBookings()
        {
            string chname = Session["username"].ToString();
            var newBookings = db.BookChoreographers.Where(a => a.choreographername == chname && a.BookingStatus == "Pending").ToList();
            return View(newBookings);
        }

        public ActionResult changeBookingStatus(int id)
        {
            string msg = "Something Went Wrong";
            var res = db.BookChoreographers.Where(a => a.BookingId == id).SingleOrDefault();
            if (res != null)
            {
                res.BookingStatus = "Accepted";
                db.SaveChanges();
                msg = "Accepted";
            }
            return new JsonResult { Data = new { message = msg } };
        }

        public ActionResult addAttendance()
        {
            string chname = Session["username"].ToString();
            var bookings = db.BookChoreographers.Where(a => a.choreographer.username == chname && a.BookingStatus == "Accepted" && a.Attendancegiven == "No").ToList();
            //var res = db.Attendances.ToList();
            List<int> bookingIds = getAllBookingIds(bookings);
            List<AttendanceViewModel> attvm = new List<AttendanceViewModel>();
            foreach (var item in bookings)
            {
                if (item.BookingStatus != "Pending")
                {
                    AttendanceViewModel vm = new AttendanceViewModel();
                    vm.BookingId = item.BookingId;
                    vm.CustomerName = item.StudentName;
                    attvm.Add(vm);
                }
            }
            if (attvm != null) { return View(attvm); }
            return View();
        }

        [HttpPost]
        public ActionResult addAttendance(List<AttendanceViewModel> attvm)
        {
            if (attvm != null)
            {
                for (int i = 0; i < attvm.Count; i++)
                {
                    Attendance att = new Attendance();
                    att.BookingId = attvm[i].BookingId;
                    att.isPresent = attvm[i].isPresent;
                    db.Attendances.Add(att);
                    int id = Convert.ToInt32(attvm[i].BookingId);
                    var changeAttendanceStatus = db.BookChoreographers.Where(a => a.BookingId == id).SingleOrDefault();
                    changeAttendanceStatus.Attendancegiven = attvm[i].isPresent;
                    db.Entry(changeAttendanceStatus).State = EntityState.Modified;
                }
                db.SaveChanges();
                return Json("ok", JsonRequestBehavior.AllowGet);
            }
            return View();
        }

        public ActionResult assignRewards()
        {
            var attendance = db.Attendances.Where(a => a.isPresent == "Yes").ToList();
            List<BookChoreographer> bookChoreographers = getBookingsById(attendance);
            List<Reward> reward = new List<Reward>();
            foreach (var item in bookChoreographers)
            {
                Reward rew = new Reward();
                rew.BookingId = item.BookingId;
                rew.choreographername = item.choreographername;
                rew.StudentName = item.StudentName;
                reward.Add(rew);
            }
            return View(reward);
        }

        [HttpPost]
        public ActionResult assignRewards(List<Reward> rewards)
        {
            if (rewards != null)
            {
                foreach (var item in rewards)
                {
                    Reward rew = new Reward();
                    String[] spearator = { "'" };
                    String[] studentName = item.StudentName.Split(spearator, StringSplitOptions.RemoveEmptyEntries);
                    String[] choreographername = item.choreographername.Split(spearator, StringSplitOptions.RemoveEmptyEntries);
                    rew.BookingId = item.BookingId;
                    rew.StudentName = studentName[0];
                    rew.choreographername = choreographername[0];
                    rew.Rewards = item.Rewards;
                    db.Rewards.Add(rew);
                    var changeRewardsStatus = db.BookChoreographers.Where(a => a.BookingId == item.BookingId).SingleOrDefault();
                    changeRewardsStatus.Rewardsgiven = "Yes";
                    db.Entry(changeRewardsStatus).State = EntityState.Modified;
                }
                db.SaveChanges();
                return Json("ok", JsonRequestBehavior.AllowGet);
            }
            return Json("error", JsonRequestBehavior.AllowGet);
        }

        public List<int> getAllBookingIds(List<BookChoreographer> bookings)
        {
            List<int> bookingIds = new List<int>();
            foreach (var item in bookings)
            {
                if (item.BookingStatus != "Pending")
                {
                    bookingIds.Add(item.BookingId);
                }
            }
            return bookingIds;
        }

        public List<BookChoreographer> getBookingsById(List<Attendance> attendances)
        {
            List<BookChoreographer> bookch = new List<BookChoreographer>();
            string chname = Session["username"].ToString();
            var bookings = db.BookChoreographers.Where(a => a.Rewardsgiven == "No" && a.Attendancegiven == "Yes" && a.choreographername == chname).ToList();
            List<int> bookId = new List<int>();
            foreach (var item in attendances)
            {
                bookId.Add(Convert.ToInt32(item.BookingId));
            }
            foreach (var item in bookings)
            {
                if (bookId.Contains(Convert.ToInt32(item.BookingId)))
                {
                    bookch.Add(item);
                }
                //bookch.Add(item);
            }
            return bookch;
        }

        public ActionResult ViewFeedbacks()
        {
            string name = Session["username"].ToString();
            var res = db.Feedbacks.Where(a => a.ChoreographerName == name).ToList();
            return View(res);
        }
        
        [HttpPost]
        public JsonResult IsAlreadyExists(string username)
        {
            return Json(IsUsernameAvailable(username));
        }

        public bool IsUsernameAvailable(string username)
        {
            bool status = true;
            var UsernameExists = db.choreographers.Where(a => a.username.ToUpper() == username.ToUpper()).FirstOrDefault();
            if (UsernameExists != null)
            {
                status = false;
                return status;
            }
            return status;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}


create schema Academy

create table Academy.choreographer
(
	username varchar(10) primary key,
	[Name] varchar(25),
	[password] varchar(25) not null,
	DanceType varchar(10) not null,
	Email varchar(50) not null,
	Gender varchar(6) not null,
	DOB datetime not null,
	City varchar(25) not null,
	MobileNumber varchar(10) not null
)

select * from Academy.choreographer


create table Academy.Users
(
	username varchar(10) primary key,
	[Name] varchar(25),
	[password] varchar(25) not null,
	DanceType varchar(10) not null,
	Email varchar(50) not null,
	Gender varchar(6) not null,
	DOB datetime not null,
	City varchar(25) not null,
	MobileNumber varchar(10) not null
)


select * from Academy.Users



create table Academy.BookChoreographer
(
	BookingId int Identity(100,1) primary key,
	danceType varchar(10) not null,
	StudentName varchar(10) foreign key references Academy.Users(username) on delete cascade,
	choreographername varchar(10) foreign key references Academy.choreographer(username) on delete cascade,
	BookingDate datetime not null,
	Email varchar(50),
	BookingType varchar(10) check (BookingType in ('Home', 'Studio')),
	City varchar(25) not null,
	MobileNumber varchar(10) not null,
	StudentStrength int not null,
	BookingStatus varchar(10), 
	Rewardsgiven varchar(3),
	Attendancegiven varchar(3)
)


select * from Academy.BookChoreographer

select * from Academy.Attendance



update Academy.BookChoreographer set BookingStatus = 'Pending' where BookingId = 110
update Academy.BookChoreographer set Rewardsgiven = 'Yes' where BookingId = 100

create table Academy.Attendance
(
	
	AttendanceId int Identity primary key,

	BookingId int foreign key references Academy.BookChoreographer(BookingId) on delete cascade,

	isPresent varchar(3)
)


create table Academy.Rewards
(
	id int identity primary key,
	BookingId int foreign key references Academy.BookChoreographer(BookingId),
	StudentName varchar(10) foreign key references Academy.Users(username) on delete cascade,
	choreographername varchar(10) foreign key references Academy.choreographer(username) on delete cascade,
	Rewards int 
)
select * from Academy.Attendance


create table Academy.Feedback
(
	id int identity primary key,
	BookingId int foreign key references Academy.BookChoreographer(BookingId),
	StudentName varchar(10) foreign key references Academy.Users(username) on delete cascade,
	ChoreographerName varchar(10) foreign key references Academy.choreographer(username) on delete cascade,
	Feedback varchar(1000)
)

create table Academy.Adminlogin
(
	Id int Identity primary key,
	AdminUserName varchar(10) not null,
	AdminPassword varchar(25) not null
)

insert into Academy.Adminlogin values('admin', 'admin')


create table Academy.ChoreographerLoginCredential
(
	Id int Identity primary key,
	username varchar(10) not null,
	[password] varchar(25) not null
)
select *from Academy.UserLoginCredential

create table Academy.UserLoginCredential
(
	Id int Identity primary key,
	username varchar(10) not null,
	[password] varchar(25) not null
)



drop table Academy.UserLoginCredential
drop table Academy.ChoreographerLoginCredential
drop table Academy.Adminlogin
drop table Academy.BookChoreographer
drop table Academy.Attendance
drop table Academy.Rewards
drop table Academy.Feedback
drop table Academy.choreographer
drop table Academy.Users